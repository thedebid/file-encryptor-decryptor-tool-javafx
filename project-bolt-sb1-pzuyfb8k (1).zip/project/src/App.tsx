import React, { useState } from 'react';
import { Upload, Shield, Download, Lock, Unlock, File, CheckCircle, AlertCircle } from 'lucide-react';

interface FileInfo {
  name: string;
  size: string;
  type: string;
}

function App() {
  const [selectedFile, setSelectedFile] = useState<FileInfo | null>(null);
  const [operation, setOperation] = useState<'encrypt' | 'decrypt'>('encrypt');
  const [algorithm, setAlgorithm] = useState('AES-256');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isProcessed, setIsProcessed] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);

  const algorithms = [
    'AES-256',
    'AES-192',
    'AES-128',
    'ChaCha20',
    'Blowfish',
    'Twofish'
  ];

  const handleFileSelect = (file: File) => {
    const fileInfo: FileInfo = {
      name: file.name,
      size: (file.size / 1024 / 1024).toFixed(2) + ' MB',
      type: file.type || 'Unknown'
    };
    setSelectedFile(fileInfo);
    setIsProcessed(false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) return;

    setIsProcessing(true);
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsProcessing(false);
    setIsProcessed(true);
  };

  const handleDownload = () => {
    // Simulate file download
    const link = document.createElement('a');
    link.href = '#';
    link.download = `${operation}ed_${selectedFile?.name}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-2xl mb-6">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">SecureVault</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Protect your files with military-grade encryption. Upload, encrypt, and download your secure files with ease.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-3xl shadow-xl p-8 space-y-8">
          {/* File Upload Area */}
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-gray-900 flex items-center gap-3">
              <Upload className="w-6 h-6 text-blue-600" />
              Select File
            </h2>
            
            <div
              className={`relative border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-300 ${
                isDragOver
                  ? 'border-blue-500 bg-blue-50 scale-105'
                  : selectedFile
                  ? 'border-green-300 bg-green-50'
                  : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50'
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <input
                type="file"
                onChange={handleFileInputChange}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                accept="*/*"
              />
              
              {selectedFile ? (
                <div className="space-y-4">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full">
                    <File className="w-8 h-8 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{selectedFile.name}</h3>
                    <p className="text-sm text-gray-500">{selectedFile.size} • {selectedFile.type}</p>
                  </div>
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
                    <CheckCircle className="w-4 h-4" />
                    File Ready
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full">
                    <Upload className="w-8 h-8 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">
                      {isDragOver ? 'Drop your file here' : 'Upload your file'}
                    </h3>
                    <p className="text-sm text-gray-500 mt-2">
                      Drag and drop your file here, or click to browse
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                      Supports all file types • Max size: 100MB
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Operation Selection */}
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-gray-900">Operation</h2>
            <div className="grid grid-cols-2 gap-4">
              <label className={`relative flex items-center justify-center p-6 rounded-2xl border-2 cursor-pointer transition-all duration-300 ${
                operation === 'encrypt'
                  ? 'border-blue-500 bg-blue-50 shadow-lg scale-105'
                  : 'border-gray-200 hover:border-blue-300 hover:bg-blue-50'
              }`}>
                <input
                  type="radio"
                  name="operation"
                  value="encrypt"
                  checked={operation === 'encrypt'}
                  onChange={(e) => setOperation(e.target.value as 'encrypt')}
                  className="sr-only"
                />
                <div className="text-center">
                  <Lock className={`w-8 h-8 mx-auto mb-3 ${operation === 'encrypt' ? 'text-blue-600' : 'text-gray-400'}`} />
                  <h3 className={`font-semibold ${operation === 'encrypt' ? 'text-blue-900' : 'text-gray-700'}`}>
                    Encrypt
                  </h3>
                  <p className={`text-sm mt-1 ${operation === 'encrypt' ? 'text-blue-600' : 'text-gray-500'}`}>
                    Secure your file
                  </p>
                </div>
              </label>

              <label className={`relative flex items-center justify-center p-6 rounded-2xl border-2 cursor-pointer transition-all duration-300 ${
                operation === 'decrypt'
                  ? 'border-green-500 bg-green-50 shadow-lg scale-105'
                  : 'border-gray-200 hover:border-green-300 hover:bg-green-50'
              }`}>
                <input
                  type="radio"
                  name="operation"
                  value="decrypt"
                  checked={operation === 'decrypt'}
                  onChange={(e) => setOperation(e.target.value as 'decrypt')}
                  className="sr-only"
                />
                <div className="text-center">
                  <Unlock className={`w-8 h-8 mx-auto mb-3 ${operation === 'decrypt' ? 'text-green-600' : 'text-gray-400'}`} />
                  <h3 className={`font-semibold ${operation === 'decrypt' ? 'text-green-900' : 'text-gray-700'}`}>
                    Decrypt
                  </h3>
                  <p className={`text-sm mt-1 ${operation === 'decrypt' ? 'text-green-600' : 'text-gray-500'}`}>
                    Restore your file
                  </p>
                </div>
              </label>
            </div>
          </div>

          {/* Algorithm Selection */}
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-gray-900">Encryption Algorithm</h2>
            <select
              value={algorithm}
              onChange={(e) => setAlgorithm(e.target.value)}
              className="w-full p-4 border border-gray-300 rounded-2xl text-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-300 appearance-none bg-white"
            >
              {algorithms.map((alg) => (
                <option key={alg} value={alg}>
                  {alg}
                </option>
              ))}
            </select>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <AlertCircle className="w-4 h-4" />
              <span>AES-256 is recommended for maximum security</span>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={!selectedFile || isProcessing}
            className={`w-full py-4 px-8 rounded-2xl font-semibold text-lg transition-all duration-300 ${
              !selectedFile || isProcessing
                ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                : operation === 'encrypt'
                ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:shadow-xl transform hover:-translate-y-1'
                : 'bg-green-600 hover:bg-green-700 text-white shadow-lg hover:shadow-xl transform hover:-translate-y-1'
            }`}
          >
            {isProcessing ? (
              <div className="flex items-center justify-center gap-3">
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Processing...
              </div>
            ) : (
              `${operation.charAt(0).toUpperCase() + operation.slice(1)} File`
            )}
          </button>

          {/* Download Section */}
          {isProcessed && (
            <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl p-8 space-y-6 border border-green-200">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-2">
                  {operation === 'encrypt' ? 'File Encrypted Successfully!' : 'File Decrypted Successfully!'}
                </h3>
                <p className="text-gray-600">
                  Your file has been processed using {algorithm} algorithm
                </p>
              </div>
              
              <button
                onClick={handleDownload}
                className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white py-4 px-8 rounded-2xl font-semibold text-lg transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1 flex items-center justify-center gap-3"
              >
                <Download className="w-6 h-6" />
                Download {operation === 'encrypt' ? 'Encrypted' : 'Decrypted'} File
              </button>
            </div>
          )}
        </form>

        {/* Footer */}
        <div className="text-center mt-12 text-gray-500">
          <p className="text-sm">
            🔒 Your files are processed locally and never stored on our servers
          </p>
        </div>
      </div>
    </div>
  );
}

export default App;